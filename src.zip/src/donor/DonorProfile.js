import React, { useEffect, useState } from "react";
import { useAuth } from "../auth/useAuth";
import { getDonor, updateDonor } from "../services/donorService";
import Toast from "../shared/Toast";

export default function DonorProfile() {
  const { user } = useAuth();
  const [donor, setDonor] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(()=>{
    if (!user) return;
    getDonor(user.id).then(setDonor);
  },[user]);

  const save = async (e) => {
    e.preventDefault();
    try{
      const updated = await updateDonor(user.id, donor);
      setDonor(updated);
      setToast({ type:"success", message:"Profile updated" });
    }catch(e){
      setToast({ type:"error", message:"Failed to update profile" });
    }
  };

  if (!donor) return <div className="card">Loading profile…</div>;

  return (
    <form className="card grid grid-2" onSubmit={save}>
      <div>
        <label>Name</label>
        <input className="input" value={donor.name||""} onChange={e=>setDonor({...donor, name:e.target.value})} />
      </div>
      <div>
        <label>Age</label>
        <input className="input" type="number" value={donor.age||""} onChange={e=>setDonor({...donor, age:Number(e.target.value)})} />
      </div>
      <div>
        <label>Blood Group</label>
        <input className="input" value={donor.bloodGroup||""} onChange={e=>setDonor({...donor, bloodGroup:e.target.value})} />
      </div>
      <div>
        <label>Organs (comma)</label>
        <input className="input" value={donor.organList||""} onChange={e=>setDonor({...donor, organList:e.target.value})} />
      </div>
      <div style={{ gridColumn:"1 / -1" }}>
        <label>Medical Info</label>
        <textarea rows="3" value={donor.medicalInfo||""} onChange={e=>setDonor({...donor, medicalInfo:e.target.value})} />
      </div>
      <div style={{ gridColumn:"1 / -1" }}>
        <button className="btn primary" type="submit">Save</button>
      </div>
      {toast && <Toast {...toast} onClose={()=>setToast(null)} />}
    </form>
  );
}
