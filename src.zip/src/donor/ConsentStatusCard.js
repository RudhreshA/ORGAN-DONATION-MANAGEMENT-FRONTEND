import React from "react";
export default function ConsentStatusCard({ status }) {
  return <div className="badge">Consent: {status}</div>;
}
