import React from "react";
export default function HospitalBankManagement(){
  return <div className="card">Manage Hospitals & Banks (extend as needed)</div>
}
