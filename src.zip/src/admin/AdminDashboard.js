import React from "react";
export default function AdminDashboard(){
  return <div className="card">
    <h3>Admin Overview</h3>
    <div className="small">Use the sidebar to manage users, hospitals & banks, and view reports.</div>
  </div>
}
