import React from "react";
export default function ReportsAnalytics(){
  return <div className="card">Reports & Analytics (placeholder)</div>
}
