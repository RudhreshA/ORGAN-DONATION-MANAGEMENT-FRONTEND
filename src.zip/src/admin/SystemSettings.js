import React from "react";
export default function SystemSettings(){
  return <div className="card">System Settings</div>
}
