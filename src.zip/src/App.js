import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./shared/Navbar";
import Sidebar from "./shared/Sidebar";
import LoadingSpinner from "./shared/LoadingSpinner";
import RoleSwitcher from "./shared/RoleSwitcher";
import Login from "./auth/Login";
import Register from "./auth/Register";
import ProtectedRoute from "./auth/ProtectedRoute";
import { AuthProvider, useAuth } from "./auth/useAuth";

// Donor
import DonorDashboard from "./donor/DonorDashboard";
import DonorProfile from "./donor/DonorProfile";
import UploadDocuments from "./donor/UploadDocuments";

// Hospital
import HospitalDashboard from "./hospital/HospitalDashboard";
import OrganRequestForm from "./hospital/OrganRequestForm";

// Organ Bank
import OrganBankDashboard from "./organbank/OrganBankDashboard";
import AvailableOrgans from "./organbank/AvailableOrgans";
import AddOrganForm from "./organbank/AddOrganForm";
import RequestManager from "./organbank/RequestManager";

// Admin
import AdminDashboard from "./admin/AdminDashboard";
import UserManagement from "./admin/UserManagement";
import HospitalBankManagement from "./admin/HospitalBankManagement";
import ReportsAnalytics from "./admin/ReportsAnalytics";

function Layout({ children }) {
  const { user } = useAuth();
  return (
    <div>
      <Navbar />
      <div className="container" style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16 }}>
        {user && <Sidebar />}
        <div>{children}</div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <React.Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Layout><Login /></Layout>} />
          <Route path="/register" element={<Layout><Register /></Layout>} />

          {/* Donor */}
          <Route path="/donor/dashboard" element={
            <ProtectedRoute roles={["DONOR"]}><Layout><DonorDashboard /></Layout></ProtectedRoute>
          } />
          <Route path="/donor/profile" element={
            <ProtectedRoute roles={["DONOR"]}><Layout><DonorProfile /></Layout></ProtectedRoute>
          } />
          <Route path="/donor/documents" element={
            <ProtectedRoute roles={["DONOR"]}><Layout><UploadDocuments /></Layout></ProtectedRoute>
          } />

          {/* Hospital */}
          <Route path="/hospital/dashboard" element={
            <ProtectedRoute roles={["HOSPITAL_STAFF"]}><Layout><HospitalDashboard /></Layout></ProtectedRoute>
          } />
          <Route path="/hospital/request" element={
            <ProtectedRoute roles={["HOSPITAL_STAFF"]}><Layout><OrganRequestForm /></Layout></ProtectedRoute>
          } />

          {/* Organ Bank */}
          <Route path="/organbank/dashboard" element={
            <ProtectedRoute roles={["ORGAN_BANK_STAFF"]}><Layout><OrganBankDashboard /></Layout></ProtectedRoute>
          } />
          <Route path="/organbank/availability" element={
            <ProtectedRoute roles={["ORGAN_BANK_STAFF"]}><Layout><AvailableOrgans /></Layout></ProtectedRoute>
          } />
          <Route path="/organbank/add-organ" element={
            <ProtectedRoute roles={["ORGAN_BANK_STAFF"]}><Layout><AddOrganForm /></Layout></ProtectedRoute>
          } />
          <Route path="/organbank/requests" element={
            <ProtectedRoute roles={["ORGAN_BANK_STAFF"]}><Layout><RequestManager /></Layout></ProtectedRoute>
          } />

          {/* Admin */}
          <Route path="/admin/dashboard" element={
            <ProtectedRoute roles={["ADMIN"]}><Layout><AdminDashboard /></Layout></ProtectedRoute>
          } />
          <Route path="/admin/users" element={
            <ProtectedRoute roles={["ADMIN"]}><Layout><UserManagement /></Layout></ProtectedRoute>
          } />
          <Route path="/admin/hospitals-banks" element={
            <ProtectedRoute roles={["ADMIN"]}><Layout><HospitalBankManagement /></Layout></ProtectedRoute>
          } />
          <Route path="/admin/reports" element={
            <ProtectedRoute roles={["ADMIN"]}><Layout><ReportsAnalytics /></Layout></ProtectedRoute>
          } />

          <Route path="*" element={<Layout><div className="card">Not Found</div></Layout>} />
        </Routes>
      </React.Suspense>
    </AuthProvider>
  );
}
