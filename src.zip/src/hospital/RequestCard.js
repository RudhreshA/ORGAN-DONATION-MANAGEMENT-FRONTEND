import React from "react";

export default function RequestCard({ request }) {
  return <div className="card">#{request?.id} • {request?.organType} • {request?.status}</div>;
}
