import React, { useState } from "react";
import { createOrganRequest } from "../services/requestService";
import Toast from "../shared/Toast";

export default function OrganRequestForm({ hospitalId, onCreated }) {
  const [organType, setOrganType] = useState("Kidney");
  const [toast, setToast] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    if (!hospitalId) {
      setToast({ type: "error", message: "Hospital ID is required" });
      return;
    }
    try {
      await createOrganRequest({ organType, hospitalId });
      setToast({ type: "success", message: "Request created" });
      setOrganType("Kidney");
      if (onCreated) onCreated(); // Refresh hospital requests list
    } catch (e) {
      setToast({ type: "error", message: "Failed to create request" });
    }
  };

  return (
    <form className="card grid" onSubmit={submit} style={{ maxWidth: 480 }}>
      <h3>New Organ Request</h3>
      <div>
        <label>Organ Type</label>
        <select value={organType} onChange={(e) => setOrganType(e.target.value)}>
          <option>Kidney</option>
          <option>Liver</option>
          <option>Heart</option>
          <option>Lung</option>
        </select>
      </div>
      <button className="btn primary" type="submit">
        Submit
      </button>
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}
    </form>
  );
}
