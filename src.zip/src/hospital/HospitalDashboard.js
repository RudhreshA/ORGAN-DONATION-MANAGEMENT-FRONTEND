import React, { useEffect, useState, useCallback } from "react";
import { fetchRequestsByHospital } from "../services/requestService";
import Toast from "../shared/Toast";
import OrganRequestForm from "./OrganRequestForm";

export default function HospitalDashboard() {
  const [hospitalId, setHospitalId] = useState(null);
  const [requests, setRequests] = useState([]);
  const [toast, setToast] = useState(null);

  // Fetch logged-in hospital info
  useEffect(() => {
    const fetchHospital = async () => {
      try {
        const res = await fetch("/api/users/me"); // Replace with your endpoint
        const data = await res.json();
        if (data.hospital && data.hospital.id) {
          setHospitalId(data.hospital.id);
        } else {
          setToast({ type: "error", message: "No hospital associated with this user" });
        }
      } catch (e) {
        setToast({ type: "error", message: "Failed to fetch hospital info" });
      }
    };
    fetchHospital();
  }, []);

  // Load hospital requests
  const loadRequests = useCallback(() => {
    if (!hospitalId) return;
    fetchRequestsByHospital(hospitalId)
      .then(setRequests)
      .catch(() => setToast({ type: "error", message: "Failed to load requests" }));
  }, [hospitalId]);

  useEffect(() => {
    loadRequests();
  }, [loadRequests]);

  return (
    <div className="hospital-dashboard" style={{ display: "grid", gap: 20 }}>
      {toast && <Toast {...toast} onClose={() => setToast(null)} />}

      {/* Hospital creates new requests */}
      {hospitalId && <OrganRequestForm hospitalId={hospitalId} onCreated={loadRequests} />}

      {/* List of hospital requests */}
      <div className="card">
        <h3>Hospital Requests</h3>
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Organ</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((r) => (
              <tr key={r.id}>
                <td>{r.id}</td>
                <td>{r.organType}</td>
                <td>{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
