import React from "react";

export default function RequestList() {
  return <div className="card">Request List (optional)</div>;
}
