import React, { useEffect, useState, useCallback } from "react";
import { fetchRequests, updateRequest } from "../services/requestService";
import Toast from "../shared/Toast";

export default function RequestManager() {
  const [rows, setRows] = useState([]);
  const [toast, setToast] = useState(null);

  // Wrap loader in useCallback to satisfy react-hooks/exhaustive-deps
  const load = useCallback(() => {
    fetchRequests()
      .then(setRows)
      .catch(() =>
        setToast({ type: "error", message: "Failed to load requests" })
      );
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const setStatus = async (id, status) => {
    try {
      await updateRequest(id, { status });
      setToast({ type: "success", message: "Updated" });
      load();
    } catch (e) {
      setToast({ type: "error", message: "Failed to update" });
    }
  };

  return (
    <div className="card">
      <h3>Manage Requests</h3>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Organ</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{r.id}</td>
              <td>{r.organType}</td>
              <td>{r.status}</td>
              <td style={{ display: "flex", gap: 6 }}>
                <button className="btn" onClick={() => setStatus(r.id, "APPROVED")}>
                  Approve
                </button>
                <button
                  className="btn danger"
                  onClick={() => setStatus(r.id, "REJECTED")}
                >
                  Reject
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {toast && <Toast {...toast} onClose={() => setToast(null)} />}
    </div>
  );
}
