import api from "../utils/axiosInstance";

const login = async (payload) => {
  const { data } = await api.post("/api/auth/login", payload);
  return data; // {id,email,role}
};
const register = async (payload) => {
  const { data } = await api.post("/api/auth/register", payload);
  return data;
};
const logout = async () => {
  // if you later add a logout endpoint, call it; for now clear session client-side
  return true;
};
export default { login, register, logout };
