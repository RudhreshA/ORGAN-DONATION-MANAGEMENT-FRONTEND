import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../auth/useAuth";

export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <div className="nav">
      <div style={{ display:"flex", gap:12, alignItems:"center"}}>
        <Link to="/" className="badge">🫀 Organ Donation System</Link>
        <span className="small">Demo UI</span>
      </div>
      <div style={{ display:"flex", gap:12, alignItems:"center"}}>
        {user ? (<>
          <span className="badge">{user.email}</span>
          <span className="badge">Role: {user.role}</span>
          <button className="btn" onClick={logout}>Logout</button>
        </>) : (
          <Link to="/login" className="btn">Login</Link>
        )}
      </div>
    </div>
  );
}
