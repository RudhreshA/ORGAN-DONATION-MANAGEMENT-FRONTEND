import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../auth/useAuth";
import "./Sidebar.css";

export default function Sidebar() {
  const { user } = useAuth();
  const role = user?.role;

  const items = [];
  if (role === "DONOR") {
    items.push(
      ["Dashboard","/donor/dashboard"],
      ["Profile","/donor/profile"],
      ["Documents","/donor/documents"],
    );
  }
  if (role === "HOSPITAL_STAFF") {
    items.push(
      ["Dashboard","/hospital/dashboard"],
      ["New Request","/hospital/request"]
    );
  }
  if (role === "ORGAN_BANK_STAFF") {
    items.push(
      ["Dashboard","/organbank/dashboard"],
      ["Availability","/organbank/availability"],
      ["Add Organ","/organbank/add-organ"],
      ["Requests","/organbank/requests"]
    );
  }
  if (role === "ADMIN") {
    items.push(
      ["Dashboard","/admin/dashboard"],
      ["Users","/admin/users"],
      ["Hospitals & Banks","/admin/hospitals-banks"],
      ["Reports","/admin/reports"]
    );
  }

  return (
    <div className="sidebar-card">
      <h3>Navigation</h3>
      <div className="sidebar-links">
        {items.map(([label, href]) => (
          <Link key={href} className="btn" to={href}>{label}</Link>
        ))}
      </div>
      <footer className="sidebar-footer">
        <p>© 2025 Organ Donation System</p>
      </footer>
    </div>
  );
}
