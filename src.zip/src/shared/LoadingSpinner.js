import React from "react";

export default function LoadingSpinner() {
  return <div className="card">Loading…</div>;
}
